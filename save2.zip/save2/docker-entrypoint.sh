#!/bin/bash
if [ "$IS_PRODUCTION" = "True" ] || [ "$IS_STAGING" = "True" ]
then
  npm run build
else
  npm run dev
fi
