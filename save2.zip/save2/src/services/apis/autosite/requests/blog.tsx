// ============================================================
// API Blog
// ============================================================
// Table of Contents
// 
// - General Blog 
// - Template
// - SEO

import { BlogSite, BlogSiteCreate } from "interfaces/Blog"
import FetchAutosite from "../fetch/FetchAutosite"

// Blog: GGeneral 
// ============================================================
export async function getBlogList(): Promise<BlogSite[]> {
    return FetchAutosite(`blog/blog/`, "GET")
}

export async function getBlogSite(id:number): Promise<BlogSite> {
    return FetchAutosite(`blog/blog/${id}/`, "GET")
}

export async function createBlogSite(data:BlogSiteCreate): Promise<BlogSite> {
    return FetchAutosite(`blog/blog/`, "POST", data)
}

export async function updateBlogSite(id: number, data: {}): Promise<BlogSite> {
    return FetchAutosite(`blog/blog/${id}/`, "PUT", data)
}

export async function getBlogPosts(id:number): Promise<BlogSite> {
    return FetchAutosite(`blog/page/?blog=${id}`, "GET")
}

// Blog: Template
// ============================================================

export async function getBlogTemplateList(): Promise<[]> {
    return FetchAutosite(`blog/template/`, "GET")
}

// Blog: SEO
// ============================================================

export async function getBlogSeoOutlinkStrategy(): Promise<[]> {
    return FetchAutosite('seo/outlinkstrategy/', 'GET');
}

export async function deleteBlogSeoOutlinkStrategy(id:number): Promise<[]> {
    return FetchAutosite(`seo/outlinkstrategy/${id}/`, "DELETE")
}

export async function createBlogSeoOutlinkStrategy({data}:any): Promise<[]> {
    return FetchAutosite(`seo/outlinkstrategy/`, "POST", data)
}

export async function updateBlogSeoOutlinkStrategy({id, data}:any): Promise<[]> {
    return FetchAutosite(`seo/outlinkstrategy/${id}/`, "PUT", data)
}
