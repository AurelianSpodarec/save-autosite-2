import { createContext, useState, ReactNode  } from "react";

export const AlertContext = createContext<AlertConfig | undefined>(undefined);

function AlertProvider({ children }: {children: ReactNode}) {
    const [isOpen, setIsOpen] = useState(false);
    const [config, setConfig] = useState(
        {
            id: undefined,
            type: undefined,
            option: undefined,
            action: undefined,
            onAction: undefined,
            title: undefined,
            description: undefined,
        }
    );

    function setAlertOpen() {
        setIsOpen(true)
        document.body.style.overflow = 'hidden';
    }

    function setAlertClose() {
        setIsOpen(false)
        document.body.style.overflow = 'auto';
    }

    function setAlertConfig(data:any) {
        setConfig(data)
        setAlertOpen()
    }

    function onAction() {
        config?.onAction()
        setAlertClose()
    }
    
    const readValues = {
        children,
        alertData: config,
        alertSetConfig: setAlertConfig,

        alertIsOpen: isOpen,
        setAlertClose,
        onAction
    };

    return (
        <AlertContext.Provider value={readValues}>
            {children}
        </AlertContext.Provider>
    )
}

export default AlertProvider;

interface AlertConfig {
    children: ReactNode;
    data: {
        id: undefined;
        type?: undefined;
        option?: undefined;
        action?: () => void;
        title?: undefined;
        description?: undefined;
        onAction?: undefined;
        fields?: never[];
    };
    isOpen: boolean;
    setConfig: any;
    close: () => void;
    open: () => void;
    onValueChange: (e: any) => void;
    formState: any;
}