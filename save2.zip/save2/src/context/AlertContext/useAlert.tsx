import { useContext } from "react";
import { AlertContext } from "./alertContext";

function useAlert() {
    const context = useContext(AlertContext)

    if (context === undefined) {
        throw new Error('useAlert must be used within a AlertProvider')
    }
    return context

}

export default useAlert;
