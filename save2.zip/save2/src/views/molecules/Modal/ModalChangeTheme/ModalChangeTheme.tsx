import { updateBlogSite } from "services/apis/autosite/requests/blog";
import useWebSocketBlog from "services/apis/autosite/websocket/useWebSocketBlog";

function ModalChangeTheme(id) {
    
    const { startTask, socketResponse } = useWebSocketBlog(id);

    async function changeTheme(themeID: number) {
        await updateBlogSite(id, { 
            template: themeID 
        });
        startTask("redo_setup_wordpress")
    }

    return (
        <div>

            <div>
                <p>You are about to change theme to 1</p>
                <button>Confirm</button>
                <button>Cancel</button>
            </div>

            <div>
                <p>Please wait, your site theme is being changed</p>
                
                <div>
                    Loading Icon    
                </div>
            </div>

            <div>
                <p>Theme has been updated!</p>
                <button>Preview Site</button>
                <button>Close</button>
            </div>
        </div>
    )
}

export default ModalChangeTheme;
