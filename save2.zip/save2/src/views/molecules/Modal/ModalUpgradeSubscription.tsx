function ModalUpgradeSubscription({ isOpen, onClose }:any) {
    return (
        <div className={`relative z-30 ${isOpen ? "block" : "hidden"} `} aria-labelledby="modal-title" role="dialog" aria-modal="true">

            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>

            <div className="fixed inset-0 z-10 overflow-y-auto">
            <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center lg:p-0">
            <div className={`
                relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all lg:my-8 sm:w-full 
                h-[670px] 
                max-w-5xl
            `}>
                
                You have reached the limit to create new sites. 
                <span>Upgrade Plan</span>

                <div onClick={() => onClose()}>Close</div>

            </div>
            </div>
            </div>

        </div>
    )
}

export default ModalUpgradeSubscription
