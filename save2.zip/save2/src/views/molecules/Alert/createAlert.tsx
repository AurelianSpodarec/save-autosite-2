import * as ReactDOM from 'react-dom';
import useAlert from 'context/AlertContext/useAlert';
import AlertConfirm from './alerts/AlertConfirm';

const doc = document.getElementById('root');

function CreateAlert() {
    const { alertData, alertIsOpen } = useAlert()

    const alertOptions:any = {
        confirm: <AlertConfirm />,
    }

    // function handleAlertClose() {
    //     const handleKeyDown = (e:any) => getKey('ESC') === e.keyCode && alertContext.close();
    //     document.addEventListener('keydown', handleKeyDown);      
    //     return document.addEventListener('keydown', handleKeyDown);
    // }

    if(!alertIsOpen || !doc) return <></>
    return ReactDOM.createPortal(
        <aside
            role="alertdialog" 
            aria-modal="true"
            aria-labelledby={`${alertData?.option} ${alertData?.type}`}
            aria-describedby={`${alertData?.option} ${alertData?.type}`}
            className="z-40 fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
            // className={`
            //     fixed top-0 right-0 bottom-0 left-0 z-50 
            //     m-auto opacity-0 bg-black/50 
            //     p-4 overflow-y-auto
            //     ${alertIsOpen ? 'visible opacity-100 animate-open' : 'opacity-0 hidden'} 
            // `}
        >
            <div className="fixed inset-0 z-10 overflow-y-auto">
            <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">

                <div className="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6">
                {alertOptions[alertData?.type]}
                </div>

            </div>
            </div>
        </aside>
    , doc)
}

export default CreateAlert;