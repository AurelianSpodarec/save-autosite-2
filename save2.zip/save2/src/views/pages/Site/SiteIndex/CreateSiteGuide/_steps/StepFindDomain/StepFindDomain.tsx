import useGuide from "../../useGuide";

function StepFindDomain() {
    const { stepData, canShow } = useGuide();

    return (
        <div>

            <div>
                {!canShow && 
                    <div>Finding Domain</div> 
                }

                {canShow &&
                    <div>Domain Found!</div>
                }               
            </div>

        </div>
    )
}

export default StepFindDomain;
