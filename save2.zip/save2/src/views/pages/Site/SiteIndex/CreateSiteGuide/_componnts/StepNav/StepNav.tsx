import StepNavItem from "./StepNavItem";

function StepNav({ data, activeMenu, menuList }:any) {
    // const uniqueItems = [...new Map(data.map((item:any) => [item.menuID, item])).values()];

    const menu = [
        "keywords",
        "persona",
        "profilePicture",
        "logo",
        "domain",
        "wordpress",
        "launch"
    ]

    return (
        <div className={`hidden lg:block min-w-[270px] opacity-100 py-20`}>
        <nav className="flex px-10" aria-label="Progress">

            <ol role="list" className="space-y-6">
            {data && data.map((step:any, index:number) => (    
                <StepNavItem key={step.id} index={index} item={step} data={data} menulist={menuList} activeMenu={activeMenu} />
            ))}

            </ol>

        </nav>
        </div>
    );
}

export default StepNav;
