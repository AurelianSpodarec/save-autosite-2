import React, { useEffect } from "react";
import useGuide from "../../useGuide";
import LoadingTextualProgress from "molecules/LoadingTextualProgress/LoadingTextualProgress";
import { dataLoadingPersonaPhases } from "./dataLoadingPersonaPhases";
import useTypewriterEffect from "hooks/useTypewriterEffect";

const StepPersona = React.memo(() => {
    const { stepData, canShow, setAnimationFinished } = useGuide();

    const animatedName = useTypewriterEffect(stepData?.author_name, 20, canShow);
    const [animatedDescription, typeFinished] = useTypewriterEffect(stepData?.persona, 20, canShow);

    useEffect(() => {
        console.log("is animation finished", typeFinished)
        if(typeFinished) {
            setAnimationFinished(true)
        }
    }, [typeFinished])

    return (
        <div>
            {!canShow && (
                <div>
                    <LoadingTextualProgress data={dataLoadingPersonaPhases} />
                </div>
            )}

            {canShow && (
                <div>
                    <h3 className="text-2xl mb-2">{animatedName}</h3>
                    <p>{animatedDescription}</p>
                </div>
            )}
        </div>
    );
});

export default StepPersona;
