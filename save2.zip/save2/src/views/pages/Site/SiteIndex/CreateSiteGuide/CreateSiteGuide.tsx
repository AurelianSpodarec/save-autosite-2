import { useEffect, useRef } from 'react';
import * as ReactDOM from 'react-dom';

import GuideMenuIndex from './_steps/StepsIndex';
import useGuide from './useGuide';
import StepNav from './_componnts/StepNav/StepNav';

interface Props {
    isOpen: boolean;
    onOpen?: () => void;
    onClose: () => void;
}

const doc = document.getElementById('root');

function CreateSiteGuide({ isOpen, onOpen, onClose }:Props) {
    const { menuNext, activeMenu, menuList, isButtonActive } = useGuide();
    const modalRef = useRef(null);
    
    const handleKeyDown = event => {
        console.log("outside ")
        if (event.key === 'Enter' && isButtonActive) {
            console.log("click")
            menuNext()
        }
    };
    
    useEffect(() => {
        if (isOpen && modalRef.current) {
            modalRef?.current?.focus();
        }
    }, [isOpen, activeMenu]);

    if(!isOpen || !doc) return <></>
    return ReactDOM.createPortal(
        <div className={`relative z-30 ${isOpen ? "block" : "hidden"} `} tabIndex="0" ref={modalRef} onKeyDown={handleKeyDown} aria-labelledby="modal-title" role="dialog" aria-modal="true">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>

            <div className="fixed inset-0 z-10 overflow-y-auto">
                
                <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center lg:p-0">
                <div className={`
                        relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all lg:my-8 sm:w-full 
                        h-[670px] 
                        max-w-5xl
                    `}>
                    {/* ${isMenuFirstItem ? "lg:max-w-2xl w-full" : "lg:max-w-5xl w-full"} */}

                    <div className="flex flex-row h-full">
                        <aside className="bg-[#061d40]">
                            <StepNav data={menuList} activeMenu={activeMenu} />
                        </aside>
                        
                        <div className="w-full h-full flex flex-col">
                        
                            <header className="p-6 h-[150px] text-center">
                                <div className="h-16 w-16 mx-auto">
                                    {activeMenu?.icon}
                                </div>
                               <h3 className="text-2xl font-bold">{activeMenu?.description}</h3>
                            </header>

                            <section className="h-full w-full px-6 overflow-y-auto overflow-x-hidden custom-scrollbar">
                                <GuideMenuIndex />
                            </section>

                            <footer className="mt-auto bg-white border h-[70px]">
                            <div className="flex justify-between items-center h-full px-6">

                                <button type="button" className="text-sm text-blue-400" onClick={() => onClose()}>
                                    Cancel
                                </button>

                                <button 
                                    type='button' 
                                    onClick={() => menuNext()} 
                                    className={`step-button ${isButtonActive ? "is-active" : "cursor-not-allowed"}`}
                                >
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <div className="flex items-center text-sm">
                                        Next step
                                        <svg className="w-5 h-5" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10.5858 6.34317L12 4.92896L19.0711 12L12 19.0711L10.5858 17.6569L16.2427 12L10.5858 6.34317Z" fill="currentColor"></path>
                                        </svg>
                                    </div>
                                </button>
                                
                            </div>
                            </footer>

                        </div>
                    </div>


                </div>
                </div>
                
            </div>
        </div>
     , doc);
}

export default CreateSiteGuide;
