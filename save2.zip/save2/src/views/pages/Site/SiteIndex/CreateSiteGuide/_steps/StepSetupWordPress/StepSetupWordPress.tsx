import LoadingTextualProgress from "molecules/LoadingTextualProgress/LoadingTextualProgress";
import useGuide from "../../useGuide";
import { dataLoadingWordPressPhases } from "./dataLoadingWordPressPhases";

function StepSetupWordPress() {
    const { canShow } = useGuide();

    return (
        <div>

            <div>
                {!canShow && 
                    <LoadingTextualProgress data={dataLoadingWordPressPhases} />
                }
                {canShow &&
                    <div>WordPress Setup</div>
                }               
            </div>

        </div>
    )
}

export default StepSetupWordPress;
