import { useEffect, useState } from 'react';
import { useFormik } from 'formik';

import { keywordsValidationSchema } from './keywordsValidationSchema';
import useGuide from '../../useGuide';

import Input from "atoms/Input/Input";

function StepKeywords() {
    const { setSiteKeywords, setKeywordsValid } = useGuide();

    const formik = useFormik({
        initialValues: {
            keywords: "",
            customDomain: "ai",
            domain: null,
        },
        validationSchema: keywordsValidationSchema,
        isInitialValid: false,
        onSubmit:() => {}
    });

    useEffect(() => {
        if (formik.values) {
            const { keywords, domain, } = formik.values;
            setSiteKeywords({
                keywords,
                domain
            });
            console.log(formik)
            setKeywordsValid(prev => formik.isValid)
        }
    }, [formik.values, formik.isValid, setSiteKeywords]);

    const handleRadioButtons = (e) => {
        formik.setFieldValue('customDomain', e.target.value);
        if (e.target.value === "ai") {
          formik.setFieldValue('domain', null);
        }
    };

    return (
        <div className="overflow-auto">

            <form onSubmit={formik.handleSubmit}>
                <div className="mb-4 space-y-6">
                    <Input
                        label="Keywords"
                        className="w-full"
                        placeholder="Keywords"
                        name="keywords"
                        onChange={formik.handleChange}
                        value={formik.values.keywords}
                    />
                     {formik.errors.keywords && <div className="mt-2 text-xs text-red-500">{formik.errors.keywords}</div>}
                    <div className="grid lg:grid-cols-2 gap-4">
                        <div className="flex items-center pl-4 border border-gray-300 rounded">
                            <input
                                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2"
                                type="radio"
                                name="customDomain"
                                id="ai"
                                onChange={e => handleRadioButtons(e)}
                                value={"ai"}
                                checked={formik.values.customDomain === "ai"}
                            />
                            <label
                                htmlFor="ai"
                                className="w-full py-4 ml-2 text-sm font-medium text-gray-900"
                            >
                                Let AI find and register my domain
                            </label>
                        </div>
                        <div className="flex items-center pl-4 border border-gray-300 rounded">
                            <input
                                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 focus:ring-2"
                                type="radio"
                                name="customDomain"
                                id="customDomain"
                                onChange={e => handleRadioButtons(e)}
                                value={"customDomain"}
                            />
                            <label
                                htmlFor="custom"
                                className="w-full py-4 ml-2 text-sm font-medium text-gray-900"
                            >
                                Register specific domain
                            </label>
                        </div>
                    </div>

                    {formik.values.customDomain === "customDomain" && (
                        <>
                            <Input
                                label="Domain"
                                className="w-full"
                                placeholder="Domain"
                                name="domain"
                                onChange={formik.handleChange}
                                value={formik.values.domain}
                            />
                            {formik.errors.domain && <div className="mt-2 text-xs text-red-500">{formik.errors.domain}</div>}
                        </>
                    )}

                </div>
            </form>
        </div>
    );
}

export default StepKeywords;
