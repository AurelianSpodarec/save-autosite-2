import useGuide from "../../useGuide";

function StepRegisterDomain() {
    const { stepData, canShow } = useGuide();

    return (
        <div>

            <div>
                {!canShow && 
                    <div>Registering Domain</div> 
                }
                {canShow &&
                    <div>Completed: Domain Registered</div>
                }               
            </div>

        </div>
    )
}

export default StepRegisterDomain;
