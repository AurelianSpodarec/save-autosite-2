import react, { useState, useEffect, useMemo, createContext } from "react";
import { useNavigate } from "react-router-dom";

import useWebSocketBlog from "services/apis/autosite/websocket/useWebSocketBlog";
import { createBlogSite } from "services/apis/autosite/requests/blog";

import { configGuideMenu } from "./configGuideMenu";

export const GuideContext = createContext<any>({});

function GuideProvider({ children }: { children: React.ReactNode }) {
    const [blogID, setBlogID] = useState();

    const navigate = useNavigate();
    const { startTask, socketResponse } = useWebSocketBlog(blogID);

    const [siteKeywords, setSiteKeywords] = useState({
        keywords: "",
        domain: null,
    })
    const [keywordsValid, setKeywordsValid] = useState(false)

    const [menuList, setMenuList] = useState(configGuideMenu);
    const [activeMenu, setActiveMenu] = useState(menuList[0]);

    const [stepData, setStepData] = useState({});

    const [isTimerFinished, setIsTimerFinished] = useState(false);
    const [animationFinished, setAnimationFinished] = useState(false);
    const [stepStatus, setStepStatus] = useState(false)

    const canShow = useMemo(() => isTimerFinished && stepStatus, [
        isTimerFinished,
        stepStatus
    ]);

    const isButtonActive = useMemo(() => canShow || keywordsValid, [
        canShow,
        keywordsValid
    ]);

    // ===================================================================================
    // Timing
    // ===================================================================================

    // Timer Enter
    // ==============================================
    useEffect(() => {
        if (activeMenu.id !== "keywords") {
            const timeoutId = setTimeout(() => {
                setIsTimerFinished(true);
            },  activeMenu?.options.enter?.minDuration);
            return () => clearTimeout(timeoutId);
        }
    }, [activeMenu]);

    // Timer Exit
    // ==============================================
    useEffect(() => {
        if (stepStatus && isTimerFinished && activeMenu.id !== "keywords") {
            const timeoutId = setTimeout(() => {
                menuNext()
            }, activeMenu?.options.exit?.minDuration);
            return () => clearTimeout(timeoutId);
        }
    }, [isTimerFinished, stepData]);
  
    // ===================================================================================
    // Menu Config
    // ===================================================================================
    
    function menuNext() {
        const activeMenuItem = menuList.findIndex((item) => item === activeMenu);
        const currentItem = menuList[activeMenuItem + 1];
        
        if (currentItem && activeMenuItem + 1 < menuList.length - 1) {
            setActiveMenu(currentItem);
            nextStep()
        } else if (activeMenuItem + 1 === menuList.length - 1) {
            navigate(`app/sites/${blogID}`);
            setActiveMenu(menuList[0])
        }
    }

    // ===================================================================================
    // Functions
    // ===================================================================================

    async function nextStep() {
        if(!blogID) {
        // if (import.meta.env.VITE_ENVIRONMENT === "live") {
            console.log({siteKeywords})
            const res = await createBlogSite(siteKeywords);
            if(res) {
                setBlogID(res.id);
            }
        // } 
        // else {
            // setBlogID(3);
        // }
        }
    }

    function startActiveMenuTasks() {
        if(activeMenu.tasks) {
            if (activeMenu && activeMenu?.tasks.length && blogID) {
                activeMenu.tasks.forEach((task:any) => {
                    startTask(task);
                });
            }
            return;
        }
    }

    // ===================================================================================
    // Use Effects
    // ===================================================================================

    useEffect(() => {
        setAnimationFinished(false)
        setIsTimerFinished(false)
        setStepStatus(false)

        setKeywordsValid(false)
    }, [activeMenu])

    useEffect(() => {
        startActiveMenuTasks()
    }, [blogID, activeMenu])
 
    useEffect(() => {
        const data = socketResponse.find((item:any) => item.task === activeMenu.taskID)
            setStepData(data?.extra)
            if(data?.status === "completed") {
                setStepStatus(true)
            }
    }, [activeMenu, socketResponse])

    const contextValues = {
        setSiteKeywords,
        setKeywordsValid,
        
        menuList,
        menuNext,
        activeMenu,
        isButtonActive,
        
        socketResponse,
        nextStep,
        canShow,
        stepData,
        setAnimationFinished
    }

    return (
        <GuideContext.Provider value={contextValues}>
            {children}
        </GuideContext.Provider>
    );
}

export default GuideProvider;
