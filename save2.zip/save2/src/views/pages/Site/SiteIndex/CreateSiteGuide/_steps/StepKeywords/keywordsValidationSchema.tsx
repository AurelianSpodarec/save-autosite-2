import * as Yup from 'yup';

export const keywordsValidationSchema = Yup.object().shape({
    keywords: Yup.string()
        .required('Required'),
    customDomain: Yup.string()
        .required('Required'),
    domain: Yup.string()
        .when('customDomain', {
            is: "customDomain",
            then: () => Yup.string()
                .matches(/^(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9]+\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})?$/, 'Invalid domain')
                .required('Required'),
            otherwise:  () => Yup.string().nullable(),
        }),
});
