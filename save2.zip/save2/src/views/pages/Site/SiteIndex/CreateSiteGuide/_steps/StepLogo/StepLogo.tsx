import { configApp } from "config/configApp";
import useGuide from "../../useGuide";
import Skeleton from "atoms/Skeleton";
import { useEffect, useMemo, useState } from "react";

function StepLogo() {
    const { stepData, canShow } = useGuide();

    return (
        <div className="h-full w-full flex items-center -mt-10">
        <div className="h-[20rem] w-[20rem] mx-auto">
            {!canShow && <Skeleton type="image" height="h-full" width="w-full" />}
            {canShow && <img src={`${configApp.http}${configApp.url}${stepData && stepData.logo}`} className="w-full h-full" />}
        </div>
        </div>
    )
}

export default StepLogo;
