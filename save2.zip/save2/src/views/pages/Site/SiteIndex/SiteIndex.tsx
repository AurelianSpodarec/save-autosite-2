import { useEffect, useState } from 'react';
import { useQuery } from "@tanstack/react-query";

import { getBlogList } from 'services/apis/autosite/requests/blog';
import { getUserDetails } from 'services/apis/autosite/requests/user';

import Container from "atoms/Container";
import Button from "atoms/Button/Button";

import PageHeader from "molecules/PageHeader";
import UpgradeNotification from 'molecules/UpgradeNotification';
import ModalUpgradeSubscription from 'molecules/Modal/ModalUpgradeSubscription';

import RenderViewContent from './_components/RenderViewContent';
import CreateSiteGuide from './CreateSiteGuide/CreateSiteGuide';

function SiteIndex() {
    const [openModal, setOpenModal] = useState(false);
    const [upgrgadeModalOpen, setUpgradeModalOpen] = useState(false)

    const { isLoading, isError, data, error } = useQuery({
        queryKey: ["sites"],
        queryFn: () => getBlogList()
    })

    const subscriptionData = useQuery({
        queryKey: ["user/subscription"],
        queryFn: () => getUserDetails()
    })
    
    function createNewSite() {
        const canCreateBlog = subscriptionData?.data?.subscription?.can_create_blog
        if(canCreateBlog) {
            setOpenModal(true)
        } else {
            setUpgradeModalOpen(true)
        }
    }

    return (
        <Container>

            <UpgradeNotification />

            <CreateSiteGuide isOpen={openModal} onOpen={() => setOpenModal(true)} onClose={() => setOpenModal(false)} />
            <ModalUpgradeSubscription isOpen={upgrgadeModalOpen} onClose={() => setUpgradeModalOpen(false)} />

            <PageHeader title="All Sites" className="flex justify-between items-center align-middle">
                <Button label="New Site" onClick={() => createNewSite()} />
            </PageHeader>

            <div className="flow-root">
                <RenderViewContent isLoading={isLoading} data={data} />
            </div>
        </Container>
    )
}

export default SiteIndex;
