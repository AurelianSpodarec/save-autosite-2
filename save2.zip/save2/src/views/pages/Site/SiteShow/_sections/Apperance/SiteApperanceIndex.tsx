import { useEffect, useState } from 'react';
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

import { getBlogTemplateList, updateBlogSite } from "services/apis/autosite/requests/blog";
import useWebSocketBlog from "services/apis/autosite/websocket/useWebSocketBlog";

import PageHeader from "molecules/PageHeader";
import CardThemeItem from "./_components/CardThemeItem";
import useSite from '../../useSite';

function ModalChangeTheme({isOpen, themeID, onCloseModal}:any) {
    const { startTask, socketResponse } = useWebSocketBlog(themeID);
    console.log({themeID})

    const [activeStep, setActiveStep] = useState(0)

  
    async function changeTheme() {
        await updateBlogSite(themeID, { 
            template: themeID 
        });
        startTask("redo_setup_wordpress")
    }

    function nextStep() {
        setActiveStep(prevStep => prevStep + 1)
        changeTheme()
    }

    return (
        <div className={`${isOpen ? "block" : "hidden"} z-40 fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity`}>
        <div className="fixed inset-0 z-10 overflow-y-auto">
        <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">

            <div className="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6">


                {activeStep === 0 &&
                    <div>
                        <p>You're about to change website theme to <span className="font-bold">{themeID}</span></p>
                        <button onClick={() => nextStep()}>Confirm</button>
                        <button onClick={onCloseModal}>Cancel</button>
                    </div>
                }
                {activeStep === 1 &&
                    <div>
                        <p>Please wait, your site theme is being changed</p>
                        
                        <div>
                            Loading Icon    
                        </div>
                    </div>
                }
                {activeStep === 2 &&
                    <div>
                        <p>Theme has been updated!</p>
                        <button>Preview Site</button>
                        <button>Close</button>
                    </div>
                }
            </div>

        </div>
        </div>
        </div>
    )
}


function SiteApperanceIndex() {
    const { id } = useParams();
    const { startTask, socketResponse } = useWebSocketBlog(id);
    const { blogData } = useSite()

    const [modalOpen, setModalOpen] = useState(false)
    const [activeTheme, setActiveTheme] = useState(null)
    const activeTemplate = blogData.template

    const { isLoading, isError, data, error } = useQuery({
        queryKey: ["blog-templates"],
        queryFn: () => getBlogTemplateList()
    })

    async function changeTheme(themeID: number) {
        setModalOpen(true, themeID)
        setActiveTheme(themeID)
    }

    function onCloseModal() {
        console.log("ooo")
        setModalOpen(false)
        setActiveTheme(null)
    }

    useEffect(() => {
        const data = socketResponse.find((item: any) => item.task === "redo_setup_wordpress");
        if (data && data.status == "completed") {
            console.log("done")
        }
    }, [socketResponse])

    return (
        <div className="p-8">

            {modalOpen && 
                <ModalChangeTheme 
                    isOpen={modalOpen} 
                    onCloseModal={() => onCloseModal()} 
                    themeID={activeTheme}
                />
            }

            <PageHeader title="Website Templates" />

            <section>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {data && data.length > 0 ? (
                        data.map((item) => (
                            <CardThemeItem 
                                key={item.id}
                                isActive={activeTemplate === item.id} 
                                item={item}
                                onActivate={() => changeTheme(item.id)}
                            />
                        ))
                    ) : (
                        [...Array(10)].map((_, index) => (
                            <CardThemeItem key={index} isLoading={true} />
                        ))
                    )}
                </div>
            </section>
        </div>
    )
}

export default SiteApperanceIndex;
