import * as Yup from 'yup';
import { useFormik } from "formik";

import Input from 'atoms/Input/Input';
import { createBlogSeoOutlinkStrategy, updateBlogSeoOutlinkStrategy } from 'services/apis/autosite/requests/blog';

const outlinkSchema = Yup.object().shape({
    frequency: Yup.string().required('Frequency is required'),
    keywords: Yup.string().required('Keywords are required'),
    url: Yup.string()
    .when('customDomain', {
        is: "customDomain",
        then: () => Yup.string()
            .matches(/^(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9]+\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})?$/, 'Invalid domain')
            .required('Required'),
        otherwise:  () => Yup.string().nullable(),
    }),
});

function StrategyForm({ blogID, data, onSave, onDelete, canEdit = false }:any) {

    // isNew
    // actionOption: 'save', 'edit', 'update',
    const actionOption = data?.actionOption
    console.log(data)
        
    const formik = useFormik({
        initialValues: data || {
            frequency: "",
            keywords: "",
            url: ""
        },
        validationSchema: outlinkSchema,
        onSubmit: async values => {

            const payload = {
                blog: [parseInt(blogID)],
                frequency: parseInt(values.frequency),
                keywords: values.keywords,
                url: values.url
            };

            if(actionOption === "save") {
                createBlogSeoOutlinkStrategy({ id:data.id, data:payload })    
            } else if(actionOption === "update") {
                updateBlogSeoOutlinkStrategy(payload)
            }

            // if (res.errors) {
            //     formik.setErrors(res.errors);
            // }

        },
    });

    function onSubmitWOO(e) {
        e.preventDefault();
        formik.handleSubmit()
    }

    // If data exists, populate that into form, and it should be 'edit'
    // when user presses 'edit', it should then show inputs  that the user can edit

    return (
        <form onSubmit={e => onSubmitWOO(e)} className="border rounded-lg p-6 bg-white">

            <div className="flex items-center justify-between">
                <span className="text-2xl font-medium">Strategy</span>

                <div>
                    <label>
                        <select
                            name="frequency"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.frequency}
                            >
                            <option value="" label="Select frequency" />
                            <option value="1" label="Daily" />
                            <option value="2" label="Weekly" />
                            <option value="3" label="Monthly" />
                        </select>
                    </label>
                    {formik.touched.frequency && formik.errors.frequency && <div>{formik.errors.frequency}</div>}
                </div>
            </div>

            <div className="mb-4">
                <div>
                    <Input label="Keywords" name="keywords" onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.keywords} />
                    {formik.touched.keywords && formik.errors.keywords && <div>{formik.errors.keywords}</div>}
                </div>
                <div>
                    <Input label="URL" name="url" onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.url} />
                    {formik.touched.url && formik.errors.url && <div>{formik.errors.url}</div>}
                </div>
            </div>

            <div>
                <button type="submit" onClick={(e) => onSubmitWOO(e)}>
                    {actionOption && actionOption === "save" ? "Save" : ""}
                </button>
                <button type="button" onClick={onDelete}>Delete</button>
            </div>
        </form>
    );
}

export default StrategyForm;
