import Skeleton from "atoms/Skeleton";

function CardThemeItem({ item, onActivate, isActive, isLoading }:any) {

    if(isLoading) {
        return (
            <div>
                <Skeleton type="image" height="h-[230px]" width="w-full" gutter="mb-0" />
                
                <div className="flex flex-row justify-between mt-2">
                    <Skeleton height="h-2.5" width="w-40" />
                    <Skeleton height="h-2.5" width="w-16" />
                </div>
            </div>
        )
    }
    return (
        <div className={`group rounded-lg h-[266px] overflow-hidden ${isActive ? "bg-slate-900" : ""} `}>
            <img className="object-cover object-top shadow w-full h-[230px]" src={item.preview_image} alt="Alt Image" />
            <div className={`flex items-center justify-between px-4 text-sm py-2 ${isActive ? "text-white" : ""}`}>
                <h5><span className="font-bold">{isActive ? "Active: " : ""}</span>{item.title}</h5>
                {!isActive && <button onClick={onActivate} className="group-hover:block hidden bg-[#226f54] px-1.5 rounded text-white">Activate</button>}
            </div>
        </div>
    )
}

export default CardThemeItem;
