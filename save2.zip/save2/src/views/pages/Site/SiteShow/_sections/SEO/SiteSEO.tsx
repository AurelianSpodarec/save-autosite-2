import Button from "atoms/Button/Button";
import Card from "atoms/Card";
import PageHeader from "molecules/PageHeader";
import { NavLink, Outlet, useLocation, useParams } from "react-router-dom";

function TabLink({ label, url, isActive }:{label:string, url: string, isActive: boolean}) {

    return (
        <NavLink 
            to={url} 
            className={`
                border-b-2  ${isActive ? "border-primary" : "border-transparent"} 
            `}>
            {label}
        </NavLink>
    )
}

function SiteSEOIndex() {

    const location = useLocation();
    const currentURL = location.pathname.split("/")[5]

    function addNew() {
        
    }

    return (
        <div>

            <div className="p-8">
            <PageHeader title="Site SEO">
                <div className="flex justify-between items-center">
                    <nav className="isolate flex border-b border-gray-200 space-x-12 mt-4">
                        <TabLink label="Outlink strategy" url="outlink" isActive={currentURL === "outlink"} />
                    </nav>

                    <div>
                        <Button onClick={() => addNew()}>Add new</Button>
                    </div>
                </div>
            </PageHeader>
            </div>

            <div className="p-8">
                <Outlet />
            </div>
            
        </div>
    )
}

export default SiteSEOIndex;
