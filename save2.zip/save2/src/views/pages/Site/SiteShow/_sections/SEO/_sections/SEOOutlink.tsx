import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

import { 
    getBlogSeoOutlinkStrategy, 
    deleteBlogSeoOutlinkStrategy 
} from 'services/apis/autosite/requests/blog';

import StrategyForm from './_components/StrategyForm';
function SiteSEOOutlink() {
    const { id } = useParams();

    const [strategyData, setStrategyData] = useState([]);

    const { isLoading, isError, data, error } = useQuery({
        queryKey: ["blog-seo-outlinks-strategy"],
        queryFn: () => getBlogSeoOutlinkStrategy()
    });

    async function handleDelete(id) {
        await deleteBlogSeoOutlinkStrategy(id);
        setStrategyData(prevStrategies => prevStrategies.filter(strategy => strategy.id !== id));
    }

    // async function handleSave(updatedStrategy) {
    //     if(actionOption === "save") {
    //         createBlogSeoOutlinkStrategy({ id:data.id, data:payload })    
    //     } else if(actionOption === "update") {
    //         updateBlogSeoOutlinkStrategy(payload)
    //     }
    // }

    function addNew() {
        const newStrategy = { id: Date.now(), actionOption: "save" };
        setStrategyData(prevStrategies => [...prevStrategies, newStrategy]);
    }

    useEffect(() => {
        setStrategyData(prevData => [...prevData, data])
    }, [])

    return (
        <div>
            <button onClick={addNew}>
                Add New
            </button>
            <div className="cols grid grid-cols-3 gap-6">
                {strategyData && strategyData.map(strategy => (
                    <StrategyForm
                        key={strategy?.id}
                        blogID={id}
                        data={strategy}
                        onDelete={() => handleDelete(strategy?.id)}
                        // onSave={handleSave}
                    />
                ))}
            </div>
        </div>
    );
}

export default SiteSEOOutlink;
