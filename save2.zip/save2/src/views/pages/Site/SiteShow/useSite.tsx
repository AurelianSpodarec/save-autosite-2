import { useContext } from "react";
import { SiteContext } from "./contexetSite";

export function useSite() {
    const context = useContext(SiteContext);

    if (!context) {
        throw new Error("useSite must be used within an useSite");
    }
    
    return context;
}

export default useSite;
