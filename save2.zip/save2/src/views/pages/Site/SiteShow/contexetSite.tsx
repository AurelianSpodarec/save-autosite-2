import { useQuery } from "@tanstack/react-query";
import { BlogSite } from "interfaces/Blog";
import { useState, useEffect, createContext } from "react";
import { getBlogSite } from "services/apis/autosite/requests/blog";

import useWebSocketBlog from "services/apis/autosite/websocket/useWebSocketBlog";

export const SiteContext = createContext<any>({});

function SiteProvider({ children }: { children: React.ReactNode }) {
    const [siteID, setSiteID] = useState();
    const [blogData, setBlogData] = useState<BlogSite>({} as BlogSite);

    const { startTask, socketResponse } = useWebSocketBlog(siteID);

    const siteQuery = useQuery({
        queryKey: ["sites", siteID],
        queryFn: () => getBlogSite(siteID),
        // staleTime: Infinity,
        enabled: !!siteID,
    })

    // ===================================================================================
    // Use Effects
    // ===================================================================================

    useEffect(() => {
        if(siteQuery.data) {
            const fetchedData = {
                "persona": {
                    "author": {
                        "name": siteQuery.data?.author?.name,
                        "age": siteQuery.data?.author?.age,
                        "ethnicity": siteQuery.data?.author?.ethnicity,
                        "gender": siteQuery.data?.author?.gender,
                        "location": siteQuery.data?.author?.location,
                        "education": siteQuery.data?.author?.education,
                        "description": siteQuery.data?.author?.description
                    },
                    "title": siteQuery.data?.title,
                    "tagline": siteQuery.data?.tagline,
                    "persona": siteQuery.data?.persona
                },
                "profile_picture": siteQuery.data?.author?.profile_picture,
                "logo": siteQuery.data?.logo,
                "scheduled_posts": siteQuery.data?.scheduled_posts,
                "published_posts": siteQuery.data?.published_posts,
                "template": siteQuery.data?.template
            }
            setBlogData(fetchedData)
        }
    }, [siteQuery.data])

    function regenerateTask(task: keyof BlogSite) {
        let previousData:any = blogData[task];
    
        if (previousData !== null) {
            if (typeof previousData === "string") {

                previousData = null;
                setBlogData({ ...blogData, [task]: previousData });

            } else {
                    Object.keys(previousData).forEach((i) => {
                    if (typeof previousData[i] === "object") {
                        Object.keys(previousData[i]).forEach((item) => {
                            previousData[i][item] = null;
                        });
                    } else {
                        previousData[i] = null;
                    }
                });

                setBlogData({
                    ...blogData,
                    [task]: { ...(previousData as object) },
                });
            }
        }

        startTask(task, true)
    }

    useEffect(() => {
        socketResponse.map((item) => {
            if (item.status === "completed") {
                if(item.task === "persona") {
                    setBlogData((prevData) => ({ ...prevData, [item.task]: item.extra }));
                } else if(item.extra) {
                    setBlogData((prevData) => ({ ...prevData, [item.task]: item?.extra[item.task] }));
                }
            }
        });
    }, [socketResponse]);

    useEffect(() => {
        setBlogData({})
    }, [siteID])
      
    const contextValues = {
        siteID,
        setSiteID,
        blogData,
        regenerateTask,
        siteQuery
    }

    return (
        <SiteContext.Provider value={contextValues}>
            {children}
        </SiteContext.Provider>
    );
}

export default SiteProvider;
