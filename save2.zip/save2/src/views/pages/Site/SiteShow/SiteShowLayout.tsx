import { useState, useEffect } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import SiteNavList from './_components/SiteNav/SiteNavList';
import useSite from './useSite';

import { configPages } from 'config/configPages';
import IconStarterItem from 'assets/IconStarterItem';

function SiteShowLayout() {
    const { id } = useParams();
    const { blogData, setSiteID, siteQuery } = useSite();

    useEffect(() => {
        if (id) {
            setSiteID(id);
        }
    }, [id]);

    const { isLoading, isError, error } = siteQuery;

    if (!isLoading && isError || blogData?.response?.ok === false) {
        return (
            <div className="max-w-2xl mx-auto text-center mt-12 lg:mt-20">
            <div className="flex flex-col align-center">
                
                <div className="w-48 mx-auto opacity-90 mb-8">
                    <IconStarterItem />
                </div>
                
                <div className="mb-6 max-w-md mx-auto">
                    <h2 className='text-3xl font-bold mb-2'>Oops! The site doesn't exist</h2>
                    <p>It seems like this site doesn't exist or you don't have access to it.</p>
                </div>

                <div>
                    <NavLink to={configPages.DASHBOARD.path + configPages.SITES.path}>Go back to Sites</NavLink>
                </div>

            </div>
            </div>
        );
    } else {
        return (
            <div className="flex h-full">
            <div className="w-full">
                <header className="sticky top-0 z-20 bg-[#181818]">
                <div className="flex justify-between items-start">
                    <SiteNavList siteId={id} />
                </div>
                </header>
                <div className="h-full">
                    <Outlet />
                </div>
            </div>
            </div>
        );
    }
}

export default SiteShowLayout;
