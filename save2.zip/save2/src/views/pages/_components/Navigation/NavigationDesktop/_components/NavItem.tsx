import { Link } from "react-router-dom";

function NavItem({ item, isActive, menuExpanded, menuOpen }:Props) {
    return (
        <Link 
            to={item.url} 
            className={`
                cursor-default flex items-center px-4 py-2 text-base space-x-2 text-gray-900 rounded-lg group dark:text-gray-200 dark:hover:bg-gray-700
                ${isActive ? "bg-gray-700 text-gray-200" : ""}
            `}
        >
            <div className={`${menuExpanded ? "" : "mx-auto"} h-6 w-6 text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white`}>
                {item.icon}
            </div>
            <span className={`${menuExpanded ? "block" : "hidden"} ml-3}`} sidebar-toggle-item="">{item.name}</span>
        </Link>
    )
}

export default NavItem;

interface Props {
    item: any;
    isActive: boolean;
    menuExpanded?: boolean;
    menuOpen?: boolean;
}
