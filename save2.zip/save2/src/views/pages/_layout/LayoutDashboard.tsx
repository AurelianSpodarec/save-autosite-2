import Navigation from "pages/_components/Navigation/Navigation"
import { Outlet } from 'react-router-dom';
import useDashboard from 'context/DashboardContext/useDashboard';
import Header from "pages/_components/Header/Header";

function LayoutDashboard() {
    const { menuOpen, desktopMenuExpanded } = useDashboard()
    
    return (
        <div className="relative h-full overflow-auto overflow-x-hidden">
        <div id="context-wrap" className={`flex flex-col h-full`}> 

            <Navigation />

            <div className={`flex ${desktopMenuExpanded ? "lg:pl-72" : "lg:pl-[80px]"}  flex-col h-full relative`}>
                <Header/>
                <main className="h-full w-full">
                    <Outlet />
                </main>      
            </div>            

        </div>
        </div>
    )
}

export default LayoutDashboard;
