import CustomRoutes from "config/CustomRoutes";
import CreateAlert from "molecules/Alert/createAlert";

function Layout() {    
    return (
        <>
            <CreateAlert />
            
            <CustomRoutes />
        </>
    )
}

export default Layout;
