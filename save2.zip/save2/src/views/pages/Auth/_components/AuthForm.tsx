function AuthForm({ children, onSubmit }:AuthForm) {
    return (
        <form onSubmit={onSubmit} action="#" method="POST">
            {children}
        </form>
    )
}

export default AuthForm;

interface AuthForm {
    children: React.ReactNode;
    onSubmit: any;
}