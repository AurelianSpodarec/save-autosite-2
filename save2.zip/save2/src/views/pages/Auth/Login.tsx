import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { useFormik } from 'formik';
import * as Yup from 'yup';

import useAuth from "context/AuthContext/useAuth";

import Input from "atoms/Input/Input";
import Button from "atoms/Button/Button";
import { AuthCard, AuthForm, AuthSection } from "./_components";


interface AuthErrors {
    email: "",
    password: "",
    non_field_errors: ""
}

// TODO: Put this in a Validation Schema Files
const loginSchema = Yup.object().shape({
    email: Yup.string()
        .email()
        .required('Required'),
    password: Yup.string()
        .min(6, 'Too Short!')
        .required('Required'),
});

function Login() {
    const { login, getTokenFromLocalStorage } = useAuth();
    const navigate = useNavigate();

    const formik = useFormik({
        initialValues: {
            email: "",
            password: ""
        },
        validationSchema: loginSchema,
        onSubmit: async values => {
            if(formik.isValid) {
                const res = await login({
                    email: values.email, 
                    password: values.password
                })
                formik.setErrors(res)
            }
        },
    });

    return (
        <AuthCard title="Sign in to your account">

            <AuthForm onSubmit={formik.handleSubmit}>

                {formik.errors?.non_field_errors && formik.errors?.non_field_errors.map((error:any) => {
                    return <div key={error} className="text-red-500 mb-4">{error}</div>
                })}

                <AuthSection className="space-y-6">
                    <div>
                        <Input 
                            label="Email"
                            onChange={formik.handleChange}
                            value={formik.values.email}
                            placeholder="Your email"
                            id="email"
                            name="email"
                            type="email"
                            autoComplete="email"
                        />
                        {formik.errors.email && <div className="mt-2 text-xs text-red-500">{formik.errors.email}</div>}
                    </div>

                    <div>
                        <Input 
                            label="Password"
                            onChange={formik.handleChange}
                            value={formik.values.password}
                            placeholder="Your password"
                            id="password"
                            name="password"
                            type="password"
                            autoComplete="password"
                        />
                        {formik.errors.password && <div className="mt-2 text-xs text-red-500">{formik.errors.password}</div>}
                    </div>
                </AuthSection>

                <Button type="submit" block>Log In</Button>
            </AuthForm>
                
        </AuthCard>
    )
}

export default Login;
