export interface BlogSite {
    id: number;
    title: string;
    tagline: string;
    domain: null;
    persona: string;
    keywords: string;
    author: {
        name: string;
        gender: string;
        age: string;
        location: string;
        ethnicity: string;
        education: string;
        description: string;
        profile_picture: string | null;
    };
    logo: string | null;
    scheduled_posts: number;
    published_posts: number;
    template: null;
}

export interface BlogSiteCreate {
    keywords: string;
}